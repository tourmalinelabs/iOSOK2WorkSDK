//
//  OK2Work.h
//  OK2Work
//
//  Created by Tourmaline Labs Team.
//

#import <Foundation/Foundation.h>

//! Project version number for OK2Work.
FOUNDATION_EXPORT double OK2WorkVersionNumber;

//! Project version string for OK2Work.
FOUNDATION_EXPORT const unsigned char OK2WorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OK2Work/PublicHeader.h>
